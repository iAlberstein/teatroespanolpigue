import { Router } from 'express';
import { sequelize } from '../lib/sequelize.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { calculateSeatPrice, getSessionPricingRules, generatePricingColor, getPricingSummary, parsePricing } from '../lib/seatPricing.js';

const router = Router();

router.get('/', async (req, res) => {
  const { sessions: Session, shows: Show } = sequelize.models;
  const sessions = await Session.findAll({ 
    include: [{ model: Show, as: 'show' }],
    limit: 100,
    order: [['starts_at', 'ASC']]
  });
  res.json(sessions);
});

router.get('/:id/availability', async (req, res) => {
  const io = req.app.get('io');
  const sessionId = req.params.id;
  const seatHolds = io.seatHolds || new Map();
  const palcoHolds = io.palcoHolds || new Map();
  const pullmanState = io.pullmanState || new Map();
  const soldSeats = io.soldSeats || new Map();
  const soldPalcos = io.soldPalcos || new Map();
  const pullmanSold = io.pullmanSold || new Map();
  
  // Get blocked seats from memory or database
  const blockedSeats = io.blockedSeats || new Map();
  const blockedPalcos = io.blockedPalcos || new Map();
  const blockedGeneral = io.blockedGeneral || new Map();

  const seatMap = seatHolds.get(sessionId) || new Map();
  const palcoMap = palcoHolds.get(sessionId) || new Map();
  const pull = pullmanState.get(sessionId) || { capacity: 92, heldBySocket: new Map() };
  const totalHeld = Array.from(pull.heldBySocket?.values?.() || []).reduce((a,b)=>a+b,0);
  const soldCount = pullmanSold.get(sessionId) || 0;
  const blockedGeneralCount = blockedGeneral.get(sessionId) || 0;
  const available = Math.max(0, (pull.capacity || 92) - totalHeld - soldCount - blockedGeneralCount);
  
  // Helper to get guestId from hold (now stored directly in hold structure)
  const getHoldGuestId = (hold) => {
    if (!hold) return null;
    // New structure: { socketId, guestId, userId }
    if (typeof hold === 'object' && hold.guestId) return hold.guestId;
    // Legacy: just socketId - try to get from socket
    const socketId = typeof hold === 'string' ? hold : hold.socketId;
    const socket = io.sockets?.sockets?.get(socketId);
    return socket?.data?.guestId || null;
  };
  
  // Helper to get socketId from hold (handles both old and new structure)
  const getHoldSocketId = (hold) => {
    if (!hold) return null;
    return typeof hold === 'string' ? hold : hold.socketId;
  };

  // Load pricing from session (with fallback to show)
  let pricing = null;
  let session = null;
  
  try {
    const { sessions: Session, shows: Show, seat_pricing: SeatPricing } = sequelize.models;
    session = await Session.findByPk(sessionId, {
      include: [{ model: Show, as: 'show' }]
    });
    
    if (session) {
      // Priority 1: Session-specific pricing (override)
      pricing = parsePricing(session.pricing_json);
      // Priority 2: Show default pricing (base)
      if (!pricing && session.show) {
        pricing = parsePricing(session.show.pricing_json);
      }
    }
    
    if (!pricing) {
      console.error('[SESSIONS] No pricing found for session:', sessionId);
      return res.status(500).json({ error: 'pricing_not_configured', message: 'Precios no configurados para esta sesión' });
    }

    // Load special pricing rules and calculate seat-specific prices
    const seatPrices = {};
    const seatColors = {};
    
    try {
      const pricingRules = await getSessionPricingRules(sessionId, SeatPricing);
      
      // Calculate prices for all seats with special rules
      // For seats: iterate through all possible seat codes from matrix
      // For palcos: iterate through palco labels
      
      // Process seat-specific pricing
      for (const rule of pricingRules.seats) {
        if (rule.seat_code) {
          const rowLetter = rule.seat_code.match(/^([A-M])/)?.[1];
          const { price, source } = await calculateSeatPrice(session, SeatPricing, rule.seat_code, rowLetter);
          seatPrices[rule.seat_code] = { price, source };
          
          // Generate color based on price vs base
          let basePrice = pricing.platea_general;
          if (rule.seat_code.startsWith('PB')) basePrice = pricing.palcos_bajos;
          else if (rule.seat_code.startsWith('PA')) basePrice = pricing.palcos_altos;
          
          const color = generatePricingColor(price, basePrice);
          if (color) seatColors[rule.seat_code] = color;
        }
      }
      
      // Process row-specific pricing (for all seats in that row)
      for (const rule of pricingRules.rows) {
        if (rule.row_letter && !rule.row_letter.match(/P[AB]/)) {
          // This is a platea row, calculate for all seats in this row
          // We'll mark this row for the frontend to handle
          // The frontend will need to know which rows have special pricing
        }
      }
      
      // Process row range pricing
      for (const rule of pricingRules.ranges) {
        if (rule.row_from && rule.row_to && !rule.row_from.match(/P[AB]/)) {
          // This is a platea row range
          // Mark this range for the frontend
        }
      }
    } catch (err) {
      console.error('[SESSIONS] Error loading seat pricing rules:', err);
      // Continue without special pricing - not a fatal error
    }

    // Get pricing summary for legend
    let pricingSummary = [];
    try {
      pricingSummary = await getPricingSummary(session, SeatPricing);
    } catch (err) {
      console.error('[SESSIONS] Error generating pricing summary:', err);
    }

    res.json({
      heldSeats: Array.from(seatMap.entries()).map(([seatId, hold]) => ({ 
        seatId, 
        by: getHoldSocketId(hold),
        guestId: getHoldGuestId(hold) 
      })),
      heldPalcos: Array.from(palcoMap.entries()).map(([palco, hold]) => ({ 
        palco, 
        by: getHoldSocketId(hold),
        guestId: getHoldGuestId(hold)
      })),
      soldSeats: Array.from(soldSeats.get(sessionId) || []),
      soldPalcos: Array.from(soldPalcos.get(sessionId) || []),
      blockedSeats: Array.from(blockedSeats.get(sessionId) || []),
      blockedPalcos: Array.from(blockedPalcos.get(sessionId) || []),
      blockedGeneral: blockedGeneralCount,
      pullman: { capacity: pull.capacity || 92, available, sold: soldCount, blocked: blockedGeneralCount },
      pricing,
      seatPrices,
      seatColors,
      pricingSummary
    });
  } catch (err) {
    console.error('[SESSIONS] Error loading pricing:', err);
    return res.status(500).json({ error: 'internal_error' });
  }
});

// Get general admission availability for non-numbered venues
router.get('/:id/general-admission-availability', async (req, res) => {
  try {
    const sessionId = req.params.id;
    const { sessions: Session, shows: Show, tickets: Ticket } = sequelize.models;
    
    // Get session and show info
    const session = await Session.findByPk(sessionId, {
      include: [{ model: Show, as: 'show' }]
    });
    
    if (!session) {
      return res.status(404).json({ error: 'session_not_found', message: 'Sesión no encontrada' });
    }
    
    // Check if this is a general admission venue
    if (session.show.venue_type === 'sala_principal') {
      return res.status(400).json({ 
        error: 'invalid_venue_type', 
        message: 'Esta sesión no es de entrada general' 
      });
    }
    
    // Get capacity (from session override or show default)
    const capacity = session.capacity_override || session.show.general_capacity;
    
    if (!capacity) {
      return res.status(500).json({ 
        error: 'capacity_not_configured', 
        message: 'Capacidad no configurada para esta sesión' 
      });
    }
    
    // Count sold tickets for this session
    const soldCount = await Ticket.count({
      where: {
        session_id: sessionId,
        status: 'sold'
      }
    });
    
    const available = Math.max(0, capacity - soldCount);
    
    res.json({
      capacity,
      sold: soldCount,
      available
    });
  } catch (error) {
    console.error('[SESSIONS] Error getting general admission availability:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al obtener disponibilidad' });
  }
});

// Mark items as sold (dev/test utility). Body: { seats?: string[], palcos?: string[], pullman?: number }
router.post('/:id/sold', async (req, res) => {
  const io = req.app.get('io');
  const sessionId = req.params.id;
  const { seats = [], palcos = [], pullman = 0 } = req.body || {};

  io.soldSeats = io.soldSeats || new Map();
  io.soldPalcos = io.soldPalcos || new Map();
  io.pullmanSold = io.pullmanSold || new Map();

  // seats
  if (!io.soldSeats.has(sessionId)) io.soldSeats.set(sessionId, new Set());
  const sset = io.soldSeats.get(sessionId);
  for (const sid of seats) {
    sset.add(String(sid));
    io.to(`session:${sessionId}`).emit('seat_sold', { seatId: String(sid) });
  }

  // palcos
  if (!io.soldPalcos.has(sessionId)) io.soldPalcos.set(sessionId, new Set());
  const pset = io.soldPalcos.get(sessionId);
  for (const label of palcos) {
    pset.add(String(label));
    io.to(`session:${sessionId}`).emit('palco_sold', { palco: String(label) });
  }

  // pullman
  const prevSold = io.pullmanSold.get(sessionId) || 0;
  const newSold = Math.max(0, prevSold + (Number.isFinite(pullman) ? pullman : 0));
  io.pullmanSold.set(sessionId, newSold);
  io.to(`session:${sessionId}`).emit('pullman_sold', { sold: newSold });
  // also emit updated availability for pullman
  const pull = (io.pullmanState || new Map()).get(sessionId) || { capacity: 92, heldBySocket: new Map() };
  const totalHeld = Array.from(pull.heldBySocket?.values?.() || []).reduce((a,b)=>a+b,0);
  const available = Math.max(0, (pull.capacity || 92) - totalHeld - newSold);
  io.to(`session:${sessionId}`).emit('pullman_updated', { available, capacity: pull.capacity || 92 });

  res.json({ ok: true, soldSeats: Array.from(sset), soldPalcos: Array.from(pset), pullmanSold: newSold });
});

// Create a new session (admin only)
router.post('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const Session = sequelize.models.sessions;
    const Show = sequelize.models.shows;
    const { show_id, starts_at, capacity_override, pricing_json, palcos_individual_seats } = req.body;
    
    if (!show_id || !starts_at) {
      return res.status(400).json({ 
        error: 'missing_fields', 
        message: 'show_id y starts_at son obligatorios' 
      });
    }
    
    // Verify show exists
    const show = await Show.findByPk(show_id);
    if (!show) {
      return res.status(404).json({ error: 'show_not_found', message: 'Espectáculo no encontrado' });
    }
    
    // Calculate ends_at based on show duration (default 2 hours)
    const duration_minutes = show.duration_minutes || 120;
    const startsAt = new Date(starts_at);
    const endsAt = new Date(startsAt.getTime() + duration_minutes * 60000);
    
    const session = await Session.create({
      show_id,
      starts_at: startsAt,
      ends_at: endsAt,
      capacity_override: capacity_override || null,
      pricing_json: pricing_json || null,
      palcos_individual_seats: palcos_individual_seats !== undefined ? palcos_individual_seats : null
    });
    
    res.status(201).json(session);
  } catch (error) {
    console.error('[SESSIONS] Error creating session:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al crear sesión' });
  }
});

// Update a session (admin only)
router.put('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const Session = sequelize.models.sessions;
    const Show = sequelize.models.shows;
    const { starts_at, capacity_override, pricing_json, palcos_individual_seats } = req.body;
    
    const session = await Session.findByPk(req.params.id, {
      include: [{ model: Show, as: 'show' }]
    });
    
    if (!session) {
      return res.status(404).json({ error: 'not_found', message: 'Sesión no encontrada' });
    }
    
    // Build update object
    const updateData = {};
    
    if (starts_at) {
      const duration_minutes = session.show?.duration_minutes || 120;
      const startsAt = new Date(starts_at);
      const endsAt = new Date(startsAt.getTime() + duration_minutes * 60000);
      updateData.starts_at = startsAt;
      updateData.ends_at = endsAt;
    }
    
    if (capacity_override !== undefined) {
      updateData.capacity_override = capacity_override || null;
    }
    
    if (pricing_json !== undefined) {
      updateData.pricing_json = pricing_json || null;
    }
    
    if (palcos_individual_seats !== undefined) {
      updateData.palcos_individual_seats = palcos_individual_seats;
    }
    
    await session.update(updateData);
    
    res.json(session);
  } catch (error) {
    console.error('[SESSIONS] Error updating session:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al actualizar sesión' });
  }
});

// Delete a session (admin only)
router.delete('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const Session = sequelize.models.sessions;
    const Ticket = sequelize.models.tickets;
    
    const session = await Session.findByPk(req.params.id);
    
    if (!session) {
      return res.status(404).json({ error: 'not_found', message: 'Sesión no encontrada' });
    }
    
    // Check if session has sold tickets
    const ticketCount = await Ticket.count({ 
      where: { 
        session_id: req.params.id,
        status: 'sold'
      } 
    });
    
    if (ticketCount > 0) {
      return res.status(400).json({ 
        error: 'has_tickets', 
        message: `No se puede eliminar una sesión con ${ticketCount} entrada(s) vendida(s).` 
      });
    }
    
    await session.destroy();
    res.json({ success: true, message: 'Sesión eliminada exitosamente' });
  } catch (error) {
    console.error('[SESSIONS] Error deleting session:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al eliminar sesión' });
  }
});

export default router;
