import express from 'express';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { sequelize } from '../lib/sequelize.js';

const router = express.Router();

/**
 * Get all seat pricing rules for a session
 * GET /api/sessions/:id/seat-pricing
 */
router.get('/:id/seat-pricing', authenticateToken, requireRole('admin', 'boleteria'), async (req, res) => {
  try {
    const { sessions: Session, seat_pricing: SeatPricing } = sequelize.models;
    const sessionId = req.params.id;

    const pricingRules = await SeatPricing.findAll({
      where: { session_id: sessionId },
      order: [['priority', 'ASC'], ['id', 'ASC']]
    });

    res.json(pricingRules);
  } catch (error) {
    console.error('[SEAT_PRICING] Error fetching pricing rules:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al obtener reglas de precios' });
  }
});

/**
 * Create a new seat pricing rule
 * POST /api/sessions/:id/seat-pricing
 * Body: { seat_code?, row_letter?, row_from?, row_to?, price, priority }
 */
router.post('/:id/seat-pricing', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { sessions: Session, seat_pricing: SeatPricing } = sequelize.models;
    const sessionId = req.params.id;
    const { seat_code, row_letter, row_from, row_to, price, priority } = req.body;

    // Validate session exists
    const session = await Session.findByPk(sessionId);
    if (!session) {
      return res.status(404).json({ error: 'session_not_found', message: 'Sesión no encontrada' });
    }

    // Validate location type matches priority
    if (priority === 1 && !seat_code) {
      return res.status(400).json({ error: 'invalid_input', message: 'Para priority=1 se requiere seat_code' });
    }
    if (priority === 2 && !row_letter) {
      return res.status(400).json({ error: 'invalid_input', message: 'Para priority=2 se requiere row_letter' });
    }
    if (priority === 3 && (!row_from || !row_to)) {
      return res.status(400).json({ error: 'invalid_input', message: 'Para priority=3 se requieren row_from y row_to' });
    }

    // Validate row range
    if (row_from && row_to && row_from > row_to) {
      return res.status(400).json({ error: 'invalid_input', message: 'row_from debe ser menor o igual a row_to' });
    }

    // Validate price
    if (!price || isNaN(price) || price <= 0) {
      return res.status(400).json({ error: 'invalid_input', message: 'Precio inválido' });
    }

    const rule = await SeatPricing.create({
      session_id: sessionId,
      seat_code: seat_code || null,
      row_letter: row_letter || null,
      row_from: row_from || null,
      row_to: row_to || null,
      price: parseFloat(price),
      priority: parseInt(priority)
    });

    res.status(201).json(rule);
  } catch (error) {
    console.error('[SEAT_PRICING] Error creating pricing rule:', error);
    console.error('[SEAT_PRICING] Error details:', {
      message: error.message,
      name: error.name,
      sql: error.sql,
      parameters: error.parameters
    });
    res.status(500).json({ error: 'internal_error', message: 'Error al crear regla de precio: ' + error.message });
  }
});

/**
 * Delete a seat pricing rule
 * DELETE /api/sessions/:id/seat-pricing/:ruleId
 */
router.delete('/:id/seat-pricing/:ruleId', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { seat_pricing: SeatPricing } = sequelize.models;
    const sessionId = req.params.id;
    const ruleId = req.params.ruleId;

    const rule = await SeatPricing.findOne({
      where: { id: ruleId, session_id: sessionId }
    });

    if (!rule) {
      return res.status(404).json({ error: 'not_found', message: 'Regla no encontrada' });
    }

    await rule.destroy();
    res.json({ success: true });
  } catch (error) {
    console.error('[SEAT_PRICING] Error deleting pricing rule:', error);
    res.status(500).json({ error: 'internal_error', message: 'Error al eliminar regla de precio' });
  }
});

/**
 * Get calculated price for a specific seat
 * GET /api/sessions/:id/seat-price?seat_code=A7&row_letter=A
 */
router.get('/:id/seat-price', authenticateToken, async (req, res) => {
  try {
    const { sessions: Session, shows: Show, seat_pricing: SeatPricing } = sequelize.models;
    const sessionId = req.params.id;
    const { seat_code, row_letter } = req.query;

    if (!seat_code && !row_letter) {
      return res.status(400).json({ error: 'invalid_input', message: 'Se requiere seat_code o row_letter' });
    }

    // Get session with show pricing
    const session = await Session.findByPk(sessionId, {
      include: [{ model: Show, as: 'show' }]
    });

    if (!session) {
      return res.status(404).json({ error: 'session_not_found' });
    }

    // Parse base pricing
    const parsePricing = (pricingData) => {
      if (!pricingData) return null;
      if (typeof pricingData === 'string') {
        try {
          const parsed = JSON.parse(pricingData);
          return (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) ? parsed : null;
        } catch { return null; }
      }
      if (typeof pricingData === 'object' && Object.keys(pricingData).length > 0) {
        return pricingData;
      }
      return null;
    };

    let basePricing = parsePricing(session.pricing_json);
    if (!basePricing && session.show) {
      basePricing = parsePricing(session.show.pricing_json);
    }

    if (!basePricing) {
      return res.status(500).json({ error: 'pricing_not_configured' });
    }

    // Priority 1: Specific seat
    if (seat_code) {
      const seatRule = await SeatPricing.findOne({
        where: { session_id: sessionId, seat_code, priority: 1 }
      });
      if (seatRule) {
        return res.json({ price: seatRule.price, source: 'seat_specific' });
      }
    }

    // Priority 2: Specific row
    if (row_letter) {
      const rowRule = await SeatPricing.findOne({
        where: { session_id: sessionId, row_letter, priority: 2 }
      });
      if (rowRule) {
        return res.json({ price: rowRule.price, source: 'row_specific' });
      }

      // Priority 3: Row range
      const rangeRule = await SeatPricing.findOne({
        where: {
          session_id: sessionId,
          row_from: { [require('sequelize').Op.lte]: row_letter },
          row_to: { [require('sequelize').Op.gte]: row_letter },
          priority: 3
        }
      });
      if (rangeRule) {
        return res.json({ price: rangeRule.price, source: 'row_range' });
      }
    }

    // Fallback to base pricing
    let fallbackPrice = 0;
    if (seat_code) {
      if (seat_code.startsWith('PB')) fallbackPrice = basePricing.palcos_bajos || 0;
      else if (seat_code.startsWith('PA')) fallbackPrice = basePricing.palcos_altos || 0;
      else fallbackPrice = basePricing.platea_general || 0;
    } else {
      fallbackPrice = basePricing.platea_general || 0;
    }

    res.json({ price: fallbackPrice, source: 'base_pricing' });
  } catch (error) {
    console.error('[SEAT_PRICING] Error calculating seat price:', error);
    res.status(500).json({ error: 'internal_error' });
  }
});

export default router;
