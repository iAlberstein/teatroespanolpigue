-- Migration: Create seat_pricing table for special pricing by location
-- Allows defining specific prices for individual seats, rows, or row ranges
-- Priority system: seat_code (1) > row_letter (2) > row_range (3) > base pricing

CREATE TABLE IF NOT EXISTS seat_pricing (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_id UUID NOT NULL,
  seat_code VARCHAR(20) NULL COMMENT 'Specific seat code (e.g., "A7", "PB19")',
  row_letter CHAR(1) NULL COMMENT 'Single row letter (e.g., "A", "B")',
  row_from CHAR(1) NULL COMMENT 'Start row for range (e.g., "A")',
  row_to CHAR(1) NULL COMMENT 'End row for range (e.g., "C")',
  price DECIMAL(10,2) NOT NULL COMMENT 'Price for this location',
  priority INT NOT NULL DEFAULT 0 COMMENT '1=specific seat, 2=single row, 3=row range',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
  
  -- Constraints: only one type of location rule per record
  CONSTRAINT chk_location_type CHECK (
    (seat_code IS NOT NULL AND row_letter IS NULL AND row_from IS NULL AND row_to IS NULL) OR
    (seat_code IS NULL AND row_letter IS NOT NULL AND row_from IS NULL AND row_to IS NULL) OR
    (seat_code IS NULL AND row_letter IS NULL AND row_from IS NOT NULL AND row_to IS NOT NULL)
  ),
  
  -- Priority must match location type
  CONSTRAINT chk_priority_match CHECK (
    (seat_code IS NOT NULL AND priority = 1) OR
    (row_letter IS NOT NULL AND priority = 2) OR
    (row_from IS NOT NULL AND priority = 3)
  ),
  
  -- Row range must be valid (from <= to)
  CONSTRAINT chk_row_range_valid CHECK (
    row_from IS NULL OR row_to IS NULL OR row_from <= row_to
  )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for efficient queries
CREATE INDEX idx_seat_pricing_session_seat ON seat_pricing(session_id, seat_code);
CREATE INDEX idx_seat_pricing_session_row ON seat_pricing(session_id, row_letter);
CREATE INDEX idx_seat_pricing_session_range ON seat_pricing(session_id, row_from, row_to);
CREATE INDEX idx_seat_pricing_priority ON seat_pricing(session_id, priority);

-- Add comment to table
ALTER TABLE seat_pricing COMMENT = 'Special pricing rules for individual seats, rows, or row ranges within a session';
